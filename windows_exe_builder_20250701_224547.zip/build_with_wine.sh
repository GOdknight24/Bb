#!/bin/bash
# Windows EXE Builder with Wine for Linux
# This script sets up Wine and builds a Windows executable

echo "🍷 Windows EXE Builder with Wine for Linux"
echo "=========================================="

# Install Wine if not present
if ! command -v wine &> /dev/null; then
    echo "📦 Installing Wine..."
    sudo apt update
    sudo apt install -y wine
    
    # Configure Wine
    echo "⚙️ Configuring Wine..."
    winecfg
fi

# Download and install Python for Windows in Wine
echo "🐍 Setting up Python for Windows in Wine..."
if [ ! -f "$HOME/.wine/drive_c/Python39/python.exe" ]; then
    echo "📥 Downloading Python for Windows..."
    wget https://www.python.org/ftp/python/3.9.13/python-3.9.13-amd64.exe -O python_windows.exe
    
    echo "📦 Installing Python in Wine..."
    wine python_windows.exe /quiet InstallAllUsers=1 PrependPath=1
    
    # Clean up installer
    rm python_windows.exe
fi

# Install PyInstaller in Wine Python
echo "📦 Installing PyInstaller in Wine..."
wine /root/.wine/drive_c/Python39/python.exe -m pip install pyinstaller psutil requests opencv-python

# Build Windows executable
echo "🔨 Building Windows executable..."
wine /root/.wine/drive_c/Python39/python.exe -m PyInstaller \
    --onefile \
    --console \
    --name "SystemDataFetcher" \
    --hidden-import psutil \
    --hidden-import requests \
    --hidden-import sqlite3 \
    --hidden-import cv2 \
    --hidden-import winreg \
    --exclude-module pyautogui \
    --exclude-module tkinter \
    hi.py

if [ $? -eq 0 ]; then
    echo "✅ Wine build completed successfully!"
    echo "📁 Executable location: dist/SystemDataFetcher.exe"
    echo "🎯 This .exe should run natively on Windows!"
else
    echo "❌ Wine build failed. Trying standard PyInstaller..."
    
    # Fallback to standard PyInstaller
    pip3 install pyinstaller
    pyinstaller --onefile --console --name "SystemDataFetcher" hi.py
fi
