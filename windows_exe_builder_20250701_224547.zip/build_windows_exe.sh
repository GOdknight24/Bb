#!/bin/bash
# Windows EXE Builder for Linux
# This script converts hi.py to a Windows executable using PyInstaller

echo "🚀 Windows EXE Builder for Linux"
echo "=================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 is not installed. Please install Python3 first."
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip3 first."
    exit 1
fi

echo "📦 Installing PyInstaller..."
pip3 install pyinstaller

echo "🔨 Building Windows executable from hi.py..."

# PyInstaller command for Windows executable
pyinstaller \
    --onefile \
    --console \
    --name "SystemDataFetcher" \
    --hidden-import psutil \
    --hidden-import requests \
    --hidden-import sqlite3 \
    --hidden-import cv2 \
    --hidden-import winreg \
    --exclude-module pyautogui \
    --exclude-module tkinter \
    hi.py

if [ $? -eq 0 ]; then
    echo "✅ Build completed successfully!"
    echo "📁 Executable location: dist/SystemDataFetcher.exe"
    echo "📦 File size: $(du -h dist/SystemDataFetcher.exe | cut -f1)"
    echo ""
    echo "🎯 Next steps:"
    echo "   1. The .exe file is in the 'dist/' folder"
    echo "   2. Transfer it to any Windows machine"
    echo "   3. Run it directly - no Python installation needed!"
else
    echo "❌ Build failed. Check the error messages above."
    exit 1
fi
