SystemDataFetcher - Windows Package
==================================

This package contains the SystemDataFetcher tool for Windows.

REQUIREMENTS:
- Windows 7 or newer
- Python 3.7 or newer installed from https://python.org/downloads/
- Internet connection (for installing required packages)

INSTALLATION:
1. Extract this ZIP file to any folder
2. Double-click "run.bat" to start the program
3. The first run will automatically install required packages

FILES INCLUDED:
- hi.py - Main program file
- run.bat - Windows launcher script
- README.txt - This file

USAGE:
- Double-click "run.bat" to run the program
- The program will collect system information and save it to files
- Output files will be created in the same directory

TROUBLESHOOTING:
- If you get a "Python not found" error, install Python from python.org
- Make sure to check "Add Python to PATH" during Python installation
- Run as Administrator if you encounter permission issues

For support, please refer to the original documentation.